'use client';

import React, { useState, useEffect } from 'react';
import { 
  FileText, 
  Search, 
  Loader2, 
  CheckCircle2, 
  AlertCircle,
  Package,
  Calendar,
  Building2,
  Eye,
  ArrowLeft,
  X,
  Users,
  ClipboardList,
  Edit3,
  Plus,
  UserCheck,
  Eraser,
  Pen,
  Camera,
  Image as ImageIcon,
  Trash2,
  Calculator,
  Ban
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '@/lib/utils';
import { db } from '@/lib/firebase';
import { 
  collection, 
  query, 
  where, 
  getDocs, 
  doc, 
  getDoc, 
  setDoc, 
  updateDoc, 
  deleteDoc, 
  orderBy,
  onSnapshot,
  limit,
  serverTimestamp 
} from 'firebase/firestore';
import { handleFirestoreError, OperationType } from '@/lib/firestore-errors';
import SignatureCanvas from 'react-signature-canvas';
import { sendGoogleChatNotification } from '@/lib/notifications';

interface OrderItem {
  code?: string;
  description: string;
  planned_quantity: number;
  quantity: number | null;
  unitPrice?: number;
  totalPrice?: number;
  collector_name?: string;
  location?: string;
  is_conferred?: boolean;
}

interface PurchaseOrder {
  id: string;
  order_number: string;
  supplier_name: string;
  product_location?: string;
  date: string;
  total_amount: number;
  items: OrderItem[];
  status: 'Pendente' | 'Separada' | 'Conferida' | 'Recusado' | 'Baixada';
  pdf_url?: string;
  created_at: string;
  assigned_users?: string[]; // IDs dos usuários responsáveis
  conferred_by_id?: string;
  conferred_by_name?: string;
  conferred_at?: string;
  is_signed?: boolean;
  signed_at?: string;
  signed_by_name?: string;
  signature_url?: string;
  separated_by_id?: string;
  separated_by_name?: string;
  separated_at?: string;
  baixado_by_id?: string;
  baixado_by_name?: string;
  baixado_at?: string;
  sequence?: number | null;
  pis?: string[];
  observation?: string;
  photos?: string[];
}

interface Profile {
  id: string;
  name: string;
  email: string;
  is_super_admin?: boolean;
  allowed_groups?: string[];
}

export function SortingView({ 
  isAdmin, 
  isSuperAdmin, 
  currentUserId, 
  isConferente, 
  currentUserName, 
  userCategory, 
  isViewer, 
  allowedGroups,
  purchaseOrders = [],
  profiles = [],
  startDate,
  endDate,
  isDarkMode,
  onDateChange
}: { 
  isAdmin?: boolean, 
  isSuperAdmin?: boolean,
  currentUserId?: string,
  isConferente?: boolean,
  currentUserName?: string,
  userCategory?: string,
  isViewer?: boolean,
  allowedGroups?: string[],
  purchaseOrders?: PurchaseOrder[],
  profiles?: Profile[],
  startDate: string,
  endDate: string,
  isDarkMode?: boolean,
  onDateChange: (start: string, end: string) => void
}) {
  const [orders, setOrders] = useState<PurchaseOrder[]>(purchaseOrders);
  const [localProfiles, setLocalProfiles] = useState<Profile[]>(profiles);
  const [loading, setLoading] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [filterText, setFilterText] = useState('');
  const [opFilter, setOpFilter] = useState('');
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<'EDIT' | 'SIGN' | 'REVIEW'>('EDIT');
  const [editingOrder, setEditingOrder] = useState<PurchaseOrder | null>(null);
  const handleOpenOrder = (order: PurchaseOrder) => {
    // Agora que inicializamos com null no DB, não precisamos converter 0 para null.
    // O null representa "não processado", enquanto 0 é um valor de separação válido.
    setEditingOrder({ ...order });
  };
  const [isAssignModalOpen, setIsAssignModalOpen] = useState(false);
  const [assigningOrder, setAssigningOrder] = useState<PurchaseOrder | null>(null);
  const [currentPI, setCurrentPI] = useState('');
  const [uploadingPhotos, setUploadingPhotos] = useState(false);
  const sigCanvas = React.useRef<SignatureCanvas>(null);

  const [revertingId, setRevertingId] = useState<string | null>(null);
  const [isConferConfirming, setIsConferConfirming] = useState(false);
  const [isBaixarConfirming, setIsBaixarConfirming] = useState(false);

  // States for Calculator
  const [isCalculatorOpen, setIsCalculatorOpen] = useState(false);
  const [calcExpression, setCalcExpression] = useState('');
  const [calcResult, setCalcResult] = useState('');
  const [copiedIndicator, setCopiedIndicator] = useState(false);

  const isItemRestricted = (item: OrderItem) => {
    if (isAdmin || isSuperAdmin || !allowedGroups || allowedGroups.length === 0) return false;
    const itemLoc = (item.location || '').toUpperCase();
    return !allowedGroups.some(group => itemLoc.includes(group.toUpperCase()));
  };

  const isOrderRestricted = (order: PurchaseOrder) => {
    if (isAdmin || isSuperAdmin || !allowedGroups || allowedGroups.length === 0) return false;
    if (!order.items || order.items.length === 0) return false;
    // Se PELO MENOS UM item for acessível, o usuário vê a OP
    return !order.items.some(item => !isItemRestricted(item));
  };

  useEffect(() => {
    setOrders(purchaseOrders);
  }, [purchaseOrders]);

  useEffect(() => {
    setLocalProfiles(profiles);
  }, [profiles]);

  useEffect(() => {
    if (isEditModalOpen) {
      setError(null);
    } else {
      setIsCalculatorOpen(false);
      setCalcExpression('');
      setCalcResult('');
    }
  }, [isEditModalOpen]);

  const handleCalcClear = () => {
    setCalcExpression('');
    setCalcResult('');
  };

  const handleCalcBackspace = () => {
    setCalcExpression(prev => prev.slice(0, -1));
  };

  const handleCalcKeyPress = (key: string) => {
    setCalcExpression(prev => {
      const lastChar = prev.slice(-1);
      const isOperator = (c: string) => ['+', '-', '*', '/'].includes(c);
      if (isOperator(key) && isOperator(lastChar)) {
        return prev.slice(0, -1) + key;
      }
      return prev + key;
    });
  };

  const handleCalcEvaluate = () => {
    if (!calcExpression) return;
    try {
      let expr = calcExpression.trim();
      while (['+', '-', '*', '/'].includes(expr.slice(-1))) {
        expr = expr.slice(0, -1);
      }
      if (!expr) return;
      const sanitized = expr.replace(/[^0-9+\-*/.]/g, '');
      const evalResult = new Function(`return (${sanitized})`)();
      if (Number.isNaN(evalResult) || !Number.isFinite(evalResult)) {
        setCalcResult('Erro');
      } else {
        const rounded = Math.round(evalResult * 10000) / 10000;
        setCalcResult(rounded.toString());
      }
    } catch (err) {
      setCalcResult('Erro');
    }
  };

  const handleCalcCopy = () => {
    const valueToCopy = calcResult || calcExpression;
    if (!valueToCopy || valueToCopy === 'Erro') return;
    navigator.clipboard.writeText(valueToCopy);
    setCopiedIndicator(true);
    setTimeout(() => setCopiedIndicator(false), 2000);
  };

  const handleEditItemQuantity = (idx: number, newQty: number) => {
    if (isViewer) return;
    // Permissão: Ventisol, Ventisol + Conferente, Admin, Superadmin
    const canEditRole = isAdmin || isSuperAdmin || userCategory === 'Ventisol' || userCategory === 'Ventisol + Conferente';
    if (!canEditRole) return;

    // Nova Regra de Grupos Permitidos
    if (!isAdmin && !isSuperAdmin && allowedGroups && allowedGroups.length > 0) {
      const item = editingOrder?.items[idx];
      if (item && isItemRestricted(item)) {
        setError(`Acesso negado para o grupo ${item.location || 'não identificado'}.`);
        return;
      }
    }

    setEditingOrder(prev => {
      if (!prev) return null;
      const updatedItems = [...(prev.items || [])];
      const item = { ...updatedItems[idx] };
      const qtyValue = isNaN(newQty) ? null : newQty;
      
      // Permitimos digitar qualquer valor para não travar a UX (ex: digitar 1 para chegar em 10)
      // A validação rigorosa será feita no momento de Salvar ou Conferir.
      item.quantity = qtyValue;
      updatedItems[idx] = item;
      return { ...prev, items: updatedItems };
    });
  };

  const handleAddPI = () => {
    if (!currentPI.trim() || !editingOrder) return;
    const newPIs = [...(editingOrder.pis || []), currentPI.trim()];
    setEditingOrder({ ...editingOrder, pis: newPIs });
    setCurrentPI('');
  };

  const handleRemovePI = (piToRemove: string) => {
    if (!editingOrder) return;
    const newPIs = (editingOrder.pis || []).filter(pi => pi !== piToRemove);
    setEditingOrder({ ...editingOrder, pis: newPIs });
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0 || !editingOrder) return;

    setUploadingPhotos(true);
    try {
      console.warn("Storage desativado: Fotos não serão salvas no momento.");
      setError("O upload de fotos requer um plano pago do Firebase. Por enquanto, as fotos não podem ser salvas.");
      setTimeout(() => setError(null), 5000);
    } catch (err: any) {
      setError(`Erro ao processar fotos: ${err.message}`);
    } finally {
      setUploadingPhotos(false);
    }
  };

  const handleRemovePhoto = (urlToRemove: string) => {
    if (!editingOrder) return;
    const newPhotos = (editingOrder.photos || []).filter(url => url !== urlToRemove);
    setEditingOrder({ ...editingOrder, photos: newPhotos });
  };

  const validateQuantities = () => {
    if (!editingOrder) return true;

    const itemsWithLowerQty = editingOrder.items?.filter(item => 
      item.quantity !== null && (item.quantity as number) < item.planned_quantity
    );

    if (itemsWithLowerQty && itemsWithLowerQty.length > 0) {
      setError(`Não é possível lançar quantidade menor que o planejado. Verifique os valores na coluna "Planejado" antes de confirmar.`);
      return false;
    }
    return true;
  };

  const handleToggleItemConferred = (index: number) => {
    if (isViewer) return;
    // Permissão: Admin, Superadmin, Conferente, Ventisol + Conferente (não apenas Ventisol)
    const canConferAction = isAdmin || isSuperAdmin || isConferente || userCategory === 'Ventisol + Conferente' || userCategory === 'Conferente';
    if (!canConferAction) return;

    // Nova Regra de Grupos Permitidos
    if (!isAdmin && !isSuperAdmin && allowedGroups && allowedGroups.length > 0) {
      const item = editingOrder?.items[index];
      if (item && isItemRestricted(item)) {
        setError(`Apenas usuários do grupo ${item.location || 'N/A'} podem conferir este item.`);
        return;
      }
    }

    setEditingOrder(prev => {
      if (!prev) return null;
      const newItems = [...(prev.items || [])];
      newItems[index] = { 
        ...newItems[index], 
        is_conferred: !newItems[index].is_conferred 
      };
      return { ...prev, items: newItems };
    });
  };

  const calculatePercentages = (items: OrderItem[]) => {
    if (!items || items.length === 0) return { separation: 0, conference: 0 };
    // Consideramos separado se a quantidade não for nula (foi preenchida pelo usuário)
    // E maior ou igual a zero (conforme solicitado pelo usuário)
    const separatedCount = items.filter(i => i.quantity !== null && i.quantity >= 0).length;
    const conferredCount = items.filter(i => i.is_conferred).length;
    
    return {
      separation: Math.round((separatedCount / items.length) * 100),
      conference: Math.round((conferredCount / items.length) * 100)
    };
  };

  const updateOrder = async () => {
    if (isViewer) return;
    if (!editingOrder?.id) return;
    if (!validateQuantities()) return;

    // Validar categoria para salvar separação (apenas se não for admin/superadmin)
    const canSaveStep = isAdmin || isSuperAdmin || userCategory === 'Ventisol' || userCategory === 'Ventisol + Conferente';
    if (!canSaveStep) {
      setError("Você não tem permissão para salvar alterações nesta OP.");
      return;
    }
    
    setIsProcessing(true);
    setError(null);
    try {
      let signatureUrl = editingOrder.signature_url;

      // 1. Uso de Assinatura via Base64 diretamente
      if (sigCanvas.current && !sigCanvas.current.isEmpty()) {
        signatureUrl = sigCanvas.current.getCanvas().toDataURL('image/png');
      }

      // 2. Update Firestore
      const orderRef = doc(db, 'purchase_orders', editingOrder.id);
      const { separation } = calculatePercentages(editingOrder.items);
      const newStatus = separation === 100 ? 'Separada' : 'Pendente';
      
      await updateDoc(orderRef, {
        items: editingOrder.items,
        status: newStatus,
        signature_url: signatureUrl || '',
        pis: editingOrder.pis || [],
        observation: editingOrder.observation || '',
        photos: editingOrder.photos || [],
        sequence: editingOrder.sequence !== undefined ? editingOrder.sequence : null,
        separated_by_id: currentUserId || '',
        separated_by_name: currentUserName || '',
        separated_at: new Date().toISOString(),
        updated_at: serverTimestamp()
      });

      setIsEditModalOpen(false);
      setEditingOrder(null);
      setSuccess('Separação salva com sucesso!');
      setTimeout(() => setSuccess(null), 3000);
    } catch (err: any) {
      console.error("Erro ao atualizar OP:", err);
      setError("Erro ao salvar alterações: " + (err.message || String(err)));
      try {
        handleFirestoreError(err, OperationType.UPDATE, `purchase_orders/${editingOrder.id}`);
      } catch (e) {
        // Ignoramos
      }
    } finally {
      setIsProcessing(false);
    }
  };

  const conferOrder = async () => {
    if (isViewer) return;
    if (!editingOrder?.id) return;
    if (!validateQuantities()) return;

    // Regra estrita: 100% dos itens devem estar separados e conferidos. Sem exceção para administradores.
    const { separation, conference } = calculatePercentages(editingOrder.items);
    if (separation !== 100 || conference !== 100) {
      setError("Não é possível conferir esta OP. 100% dos itens devem estar marcados como separados e conferidos.");
      return;
    }

    // Pergunta: Admin, Superadmin e Conferentes/Ventisol+Conf podem conferir
    const canConferOP = isAdmin || isSuperAdmin || isConferente || userCategory === 'Conferente' || userCategory === 'Ventisol + Conferente';
    if (!canConferOP) {
      setError("Apenas Conferentes e Administradores podem realizar a conferência final.");
      return;
    }
    
    if (!currentUserId || !currentUserName) {
      setError("Erro de autenticação: usuário não identificado.");
      return;
    }
    
    setIsProcessing(true);
    setError(null);
    try {
      const orderRef = doc(db, 'purchase_orders', editingOrder.id);
      await updateDoc(orderRef, {
        items: editingOrder.items,
        conferred_by_id: currentUserId,
        conferred_by_name: currentUserName,
        conferred_at: new Date().toISOString(),
        status: 'Conferida',
        pis: editingOrder.pis || [],
        observation: editingOrder.observation || '',
        photos: editingOrder.photos || [],
        sequence: editingOrder.sequence !== undefined ? editingOrder.sequence : null,
        updated_at: serverTimestamp()
      });

      setIsEditModalOpen(false);
      setEditingOrder(null);
      setIsConferConfirming(false);
      setSuccess('OP Conferida com sucesso!');
      setTimeout(() => setSuccess(null), 3000);
    } catch (err: any) {
      console.error("Erro ao conferir OP:", err);
      setError("Erro ao salvar conferência: " + (err.message || String(err)));
      try {
        handleFirestoreError(err, OperationType.UPDATE, `purchase_orders/${editingOrder.id}`);
      } catch (e) {
        // Ignoramos o throw para manter estado do modal aberto com erro
      }
    } finally {
      setIsProcessing(false);
    }
  };

  const signOrder = async () => {
    if (isViewer) return;
    const currentUserProfile = localProfiles.find(p => p.id === currentUserId);
    const effectiveUserName = currentUserName || currentUserProfile?.name || currentUserProfile?.email;

    if (!editingOrder?.id) return;

    // Apenas Admin, superadmin e Conferentes podem assinar OPs
    const canSignOP = isAdmin || isSuperAdmin || isConferente || userCategory === 'Conferente' || userCategory === 'Ventisol + Conferente';
    if (!canSignOP) {
      setError("Apenas Admin, Superadmin e Conferentes podem assinar OPs.");
      return;
    }

    if (!effectiveUserName) {
      setError("Erro: Usuário não identificado. Por favor, recarregue a página.");
      return;
    }
    
    if (!sigCanvas.current || sigCanvas.current.isEmpty()) {
      setError("Por favor, realize a assinatura antes de salvar.");
      return;
    }

    setIsProcessing(true);
    setError(null);
    try {
      let signatureUrl = "";
      if (sigCanvas.current && !sigCanvas.current.isEmpty()) {
        signatureUrl = sigCanvas.current.getCanvas().toDataURL('image/png');
      }

      const orderRef = doc(db, 'purchase_orders', editingOrder.id);
      await updateDoc(orderRef, {
        signature_url: signatureUrl,
        is_signed: true,
        signed_at: new Date().toISOString(),
        signed_by_name: effectiveUserName,
        pis: editingOrder.pis || [],
        observation: editingOrder.observation || '',
        sequence: editingOrder.sequence !== undefined ? editingOrder.sequence : null,
        updated_at: serverTimestamp()
      });
      
      // Enviar notificação para o Google Chat sobre a assinatura
      const chatMessage = `✍️ *OP Assinada (Aguardando Baixa)*\n\n` +
        `*Número:* #${editingOrder.order_number}\n` +
        `*Fornecedor:* ${editingOrder.supplier_name}\n` +
        `*Assinado por:* ${effectiveUserName}\n` +
        `*Data:* ${new Date().toLocaleString('pt-BR')}`;
      
      await sendGoogleChatNotification(chatMessage, true);
      
      setIsEditModalOpen(false);
      setEditingOrder(null);
      setSuccess('Assinatura salva com sucesso!');
      setTimeout(() => setSuccess(null), 3000);
    } catch (err: any) {
      console.error("Erro ao salvar assinatura:", err);
      setError("Erro ao salvar assinatura: " + (err.message || String(err)));
      try {
        handleFirestoreError(err, OperationType.UPDATE, `purchase_orders/${editingOrder.id}`);
      } catch (e) {
        // Ignoramos
      }
    } finally {
      setIsProcessing(false);
    }
  };

  const baixarOrder = async (orderId: string) => {
    if (isViewer) return;
    if (!isAdmin && !isSuperAdmin) return;
    
    setIsProcessing(true);
    try {
      const orderToClose = orders.find(o => o.id === orderId);

      const orderRef = doc(db, 'purchase_orders', orderId);
      await updateDoc(orderRef, { 
        status: 'Baixada',
        baixado_by_id: currentUserId || '',
        baixado_by_name: currentUserName || 'Sistema',
        baixado_at: new Date().toISOString(),
        updated_at: serverTimestamp()
      });

      // Enviar notificação para o Google Chat
      if (orderToClose) {
        const message = `🚀 *OP Baixar (Concluída)*\n\n` +
          `*Número:* #${orderToClose.order_number}\n` +
          `*Fornecedor:* ${orderToClose.supplier_name}\n` +
          `*Executor:* ${currentUserName || 'Sistema'}\n` +
          `*Data:* ${new Date().toLocaleString('pt-BR')}`;
        
        await sendGoogleChatNotification(message);
      }

      setIsEditModalOpen(false);
      setEditingOrder(null);
      setIsBaixarConfirming(false);
      setSuccess('OP Baixada com sucesso!');
      setTimeout(() => setSuccess(null), 3000);
    } catch (err: any) {
      handleFirestoreError(err, OperationType.UPDATE, `purchase_orders/${orderId}`);
    } finally {
      setIsProcessing(false);
    }
  };

  const assignUsers = async (userIds: string[]) => {
    if (!assigningOrder?.id) return;
    setIsProcessing(true);
    try {
      const orderRef = doc(db, 'purchase_orders', assigningOrder.id);
      await updateDoc(orderRef, { 
        assigned_users: userIds,
        updated_at: serverTimestamp()
      });
      setIsAssignModalOpen(false);
      setAssigningOrder(null);
      setSuccess('Usuários atribuídos com sucesso!');
      setTimeout(() => setSuccess(null), 3000);
    } catch (err: any) {
      handleFirestoreError(err, OperationType.UPDATE, `purchase_orders/${assigningOrder.id}`);
    } finally {
      setIsProcessing(false);
    }
  };

  const revertOrder = async (orderId: string) => {
    if (!isAdmin) {
      setError('Apenas administradores podem reverter OPs.');
      return;
    }
    
    try {
      const orderToRevert = orders.find(o => o.id === orderId);
      if (!orderToRevert) {
        throw new Error('OP não encontrada no estado local.');
      }

      if (orderToRevert.status === 'Baixada') {
        throw new Error('Não é possível reverter uma OP com status "Baixada".');
      }

      const resetItems = (orderToRevert.items || []).map(item => ({
        ...item,
        is_conferred: false
      }));

      const orderRef = doc(db, 'purchase_orders', orderId);
      await updateDoc(orderRef, {
        status: 'Pendente',
        items: resetItems,
        conferred_by_id: null,
        conferred_by_name: null,
        conferred_at: null,
        is_signed: false,
        signed_at: null,
        signed_by_name: null,
        signature_url: null,
        updated_at: serverTimestamp()
      });

      setSuccess('OP retornada para Pendente com sucesso!');
      setRevertingId(null);
      setTimeout(() => setSuccess(null), 3000);
    } catch (err: any) {
      handleFirestoreError(err, OperationType.UPDATE, `purchase_orders/${orderId}`);
    } finally {
      setIsProcessing(false);
    }
  };

  const parseAnyDate = (rawDate: any): Date | null => {
    if (!rawDate) return null;
    let d: Date;
    
    try {
      if (typeof rawDate === 'object' && 'seconds' in rawDate) {
        d = (rawDate as any).toDate();
      } else if (typeof rawDate === 'string') {
        if (rawDate.includes('/')) {
          const parts = rawDate.split(' ')[0].split('/');
          const day = parseInt(parts[0], 10);
          const month = parseInt(parts[1], 10);
          const year = parseInt(parts[2], 10);
          d = new Date(year, month - 1, day, 0, 0, 0, 0);
        } else if (rawDate.includes('-')) {
          const parts = rawDate.split('T')[0].split('-');
          const year = parseInt(parts[0], 10);
          const month = parseInt(parts[1], 10);
          const day = parseInt(parts[2], 10);
          d = new Date(year, month - 1, day, 0, 0, 0, 0);
        } else {
          d = new Date(rawDate);
        }
      } else if (typeof rawDate === 'number') {
        d = new Date(rawDate);
      } else {
        d = new Date(rawDate);
      }
      return isNaN(d.getTime()) ? null : d;
    } catch (e) {
      return null;
    }
  };

  const formatToISODate = (date: Date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const filteredOrders = orders.filter(o => {
    // 0. Regra de Grupos Permitidos
    if (isOrderRestricted(o)) return false;

    // 1. Filtro por permissão de visualização
    const isAssigned = o.assigned_users?.includes(currentUserId || '');
    
    // 1. Super Admins e Admins vêem tudo
    // Usuários da categoria Ventisol que NÃO são admins vêem apenas as atribuições
    let canSee = false;
    
    if (isSuperAdmin || isAdmin || userCategory === 'Ventisol' || userCategory === 'Conferente') {
      canSee = true;
    } else {
      canSee = !!isAssigned;
    }

    if (!canSee) return false;

    // 2. Filtro por busca de texto (Produto/Fornecedor)
    const matchText = filterText === '' || 
      o.supplier_name.toLowerCase().includes(filterText.toLowerCase()) ||
      o.items?.some(item => item.description?.toLowerCase().includes(filterText.toLowerCase()));

    // 3. Filtro específico de OP
    const matchOP = opFilter === '' || o.order_number.toLowerCase().includes(opFilter.toLowerCase());

    // 4. Filtro de data e status dinâmico
    const today = new Date();
    const todayStr = formatToISODate(today);
    const hasActiveDateFilter = !!startDate || !!endDate;
    
    let matchLogic = false;
    const d = parseAnyDate(o.date || o.created_at);
    if (d) {
      const orderDateStr = formatToISODate(d);
      const isFinished = o.status === 'Baixada';
      
      // Está no intervalo de datas selecionado?
      const isInRange = (!startDate || orderDateStr >= startDate) && (!endDate || orderDateStr <= endDate);

      if (hasActiveDateFilter) {
        // Se há um filtro de data configurado pelo usuário, respeita estritamente o range
        matchLogic = isInRange;
      } else {
        // Sem filtro ativo: mostra se está no intervalo padrão (hoje) ou pendências de datas anteriores não finalizadas
        if (isInRange) {
          matchLogic = true;
        } else if (orderDateStr < todayStr && !isFinished) {
          matchLogic = true;
        }
      }
    } else {
      // Sem data (fallback), mostra se não estiver concluída
      matchLogic = o.status !== 'Baixada';
    }

    return matchText && matchOP && matchLogic;
  }).sort((a, b) => {
    // Nova Lógica de Priorização: Atrasadas e Não Finalizadas no Topo
    const today = new Date();
    const todayStr = formatToISODate(today);
    
    const { separation: sepA, conference: confA } = calculatePercentages(a.items);
    const { separation: sepB, conference: confB } = calculatePercentages(b.items);
    
    const finishedA = a.status === 'Baixada' || (sepA === 100 && confA === 100);
    const finishedB = b.status === 'Baixada' || (sepB === 100 && confB === 100);
    
    const dateA = a.date ? a.date.split('T')[0] : '';
    const dateB = b.date ? b.date.split('T')[0] : '';
    
    const lateAndNotFinishedA = dateA < todayStr && !finishedA;
    const lateAndNotFinishedB = dateB < todayStr && !finishedB;

    if (lateAndNotFinishedA && !lateAndNotFinishedB) return -1;
    if (!lateAndNotFinishedA && lateAndNotFinishedB) return 1;

    // Critério secundário: Sequência
    return (a.sequence || 999999) - (b.sequence || 999999);
  });

  return (
    <div className="px-2 py-3 md:py-8 md:p-8 max-w-[1600px] mx-auto">
      <AnimatePresence>
        {success && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="mb-4 md:mb-8 p-4 bg-emerald-500/10 text-emerald-500 rounded-2xl flex items-center gap-3 border border-emerald-500/20"
          >
            <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
            <p className="text-sm font-bold">{success}</p>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="mb-4 md:mb-8">
        <h2 className="text-2xl md:text-3xl font-headline font-black text-on-surface tracking-tight">Separação de OPs</h2>
        <p className="text-on-surface-variant font-medium text-sm md:text-base">Gerencie a separação física dos materiais importados.</p>
      </div>

      <div className="bg-surface-container-low p-5 rounded-3xl mb-8 border border-outline-variant/10 shadow-sm space-y-5">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
          <div className="relative md:col-span-5">
            <label className="text-[10px] font-bold text-on-surface-variant uppercase tracking-widest mb-2 block ml-1 text-opacity-70">Buscar Item ou Fornecedor</label>
            <div className="relative group">
              <input 
                type="text"
                placeholder="Ex: Descrição, material..."
                className="w-full bg-surface-container-high/50 rounded-2xl text-sm p-3.5 pl-11 outline-none border border-outline-variant/20 focus:border-primary/50 transition-all font-medium placeholder:text-on-surface-variant/40"
                value={filterText}
                onChange={(e) => setFilterText(e.target.value)}
              />
              <Search className="w-4 h-4 absolute left-4 top-1/2 -translate-y-1/2 text-on-surface-variant group-focus-within:text-primary transition-colors" />
            </div>
          </div>

          <div className="relative md:col-span-3">
            <label className="text-[10px] font-bold text-on-surface-variant uppercase tracking-widest mb-2 block ml-1 text-opacity-70">Número da OP</label>
            <div className="relative group">
              <input 
                type="text"
                placeholder="Ex: 56789"
                className="w-full bg-surface-container-high/50 rounded-2xl text-sm p-3.5 pl-11 outline-none border border-outline-variant/20 focus:border-primary/50 transition-all font-medium placeholder:text-on-surface-variant/40"
                value={opFilter}
                onChange={(e) => setOpFilter(e.target.value)}
              />
              <FileText className="w-4 h-4 absolute left-4 top-1/2 -translate-y-1/2 text-on-surface-variant group-focus-within:text-primary transition-colors" />
            </div>
          </div>

          <div className="md:col-span-4 flex items-end gap-3">
            <div className="flex-1">
              <label className="text-[10px] font-bold text-on-surface-variant uppercase tracking-widest mb-2 block ml-1 text-opacity-70">Data Inicial</label>
              <div className="relative group">
                <input 
                  type="date"
                  className="w-full bg-surface-container-high/50 rounded-2xl text-sm p-3.5 pl-11 outline-none border border-outline-variant/20 focus:border-primary/50 transition-all font-medium"
                  value={startDate}
                  onChange={(e) => onDateChange(e.target.value, endDate)}
                />
                <Calendar className="w-4 h-4 absolute left-4 top-1/2 -translate-y-1/2 text-on-surface-variant group-focus-within:text-primary transition-colors" />
              </div>
            </div>
            <div className="flex-1">
              <label className="text-[10px] font-bold text-on-surface-variant uppercase tracking-widest mb-2 block ml-1 text-opacity-70">Data Final</label>
              <div className="relative group">
                <input 
                  type="date"
                  className="w-full bg-surface-container-high/50 rounded-2xl text-sm p-3.5 pl-11 outline-none border border-outline-variant/20 focus:border-primary/50 transition-all font-medium"
                  value={endDate}
                  onChange={(e) => onDateChange(startDate, e.target.value)}
                />
                <Calendar className="w-4 h-4 absolute left-4 top-1/2 -translate-y-1/2 text-on-surface-variant group-focus-within:text-primary transition-colors" />
              </div>
            </div>
            
            {(filterText || opFilter || startDate || endDate) && (
              <button 
                onClick={() => {
                  setFilterText('');
                  setOpFilter('');
                  const today = new Date();
                  const y = today.getFullYear();
                  const m = String(today.getMonth() + 1).padStart(2, '0');
                  const d = String(today.getDate()).padStart(2, '0');
                  const dateStr = `${y}-${m}-${d}`;
                  onDateChange(dateStr, dateStr);
                }}
                className="p-3.5 bg-surface-container-high hover:bg-surface-container-highest text-error rounded-2xl transition-colors border border-outline-variant/20 shadow-sm active:scale-95"
                title="Limpar Filtros"
              >
                <Trash2 className="w-5 h-5" />
              </button>
            )}
          </div>
        </div>
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center py-20">
          <Loader2 className="w-12 h-12 animate-spin text-primary" />
          <p className="mt-4 font-bold text-on-surface-variant">Carregando OPs para separação...</p>
        </div>
      ) : filteredOrders.length === 0 ? (
        <div className="bg-surface-container-low p-12 rounded-3xl border border-dashed border-outline-variant/30 flex flex-col items-center text-center">
          <ClipboardList className="w-12 h-12 text-on-surface-variant opacity-20 mb-4" />
          <h3 className="text-xl font-bold text-on-surface">Nenhuma OP disponível</h3>
          <p className="text-on-surface-variant mt-2 text-sm">Importe arquivos via PDF na tela de importação para vê-los aqui.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredOrders.map((order) => (
            <motion.div 
              key={order.id}
              layout
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className={cn(
                "p-6 pl-8 rounded-[40px] border shadow-sm hover:shadow-xl transition-all group flex flex-col gap-6 relative overflow-hidden",
                order.status === 'Cancelada' 
                  ? "bg-red-500/5 border-red-500/20 text-red-955 dark:text-red-200/90 shadow-red-500/5 font-bold"
                  : "bg-surface-container-lowest border-outline-variant/10",
                order.status === 'Baixada' ? 'opacity-80' : ''
              )}
              onClick={() => {
                if (order.status === 'Cancelada') return;
                handleOpenOrder(order);
                if (order.status === 'Baixada') {
                  setModalMode('REVIEW');
                } else {
                  setModalMode('EDIT');
                }
                setIsEditModalOpen(true);
              }}
            >
              {/* Barra Lateral de Status */}
              <div className={cn(
                "absolute top-0 left-0 bottom-0 w-2.5 transition-all duration-500",
                order.is_signed 
                  ? "bg-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.4)]" 
                  : (calculatePercentages(order.items).separation === 100 && calculatePercentages(order.items).conference === 100)
                    ? "bg-amber-400 shadow-[0_0_15px_rgba(251,191,36,0.4)]"
                    : "bg-surface-container-highest"
              )} />
              {/* Badge de Sequência em Destaque */}
              <div className={cn(
                "absolute top-0 right-0 px-6 py-2 rounded-bl-[24px] font-black italic tracking-tighter text-lg shadow-sm z-20",
                order.sequence 
                  ? "bg-amber-500 text-white shadow-amber-500/10" 
                  : "bg-error text-white shadow-error/10"
              )}>
                {order.sequence ? `SEQ ${order.sequence}` : 'FALTA SEQ'}
              </div>
              
              {/* Cabeçalho do Card */}
              <div className="flex justify-between items-start">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary group-hover:scale-110 transition-transform">
                    <Package className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-50">OP</h4>
                    <p className="text-xl font-headline font-black text-on-surface leading-none">#{order.order_number}</p>
                  </div>
                </div>

                {/* Responsáveis Topo Direito */}
                <div className="flex -space-x-2 mr-20">
                  {order.assigned_users && order.assigned_users.length > 0 ? (
                    <>
                      {order.assigned_users.slice(0, 3).map(uid => {
                        const user = profiles.find(p => p.id === uid);
                        return (
                          <div key={uid} className="w-8 h-8 rounded-full border-2 border-surface bg-primary/10 flex items-center justify-center text-[10px] font-bold text-primary" title={user?.name}>
                            {user?.name?.[0] || '?'}
                          </div>
                        );
                      })}
                      {order.assigned_users.length > 3 && (
                        <div className="w-8 h-8 rounded-full border-2 border-surface bg-surface-container-high flex items-center justify-center text-[10px] font-bold text-on-surface-variant">
                          +{order.assigned_users.length - 3}
                        </div>
                      )}
                      {isAdmin && order.status !== 'Baixada' && (
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            setAssigningOrder(order);
                            setIsAssignModalOpen(true);
                          }}
                          className="w-8 h-8 rounded-full border-2 border-surface bg-surface-container-high flex items-center justify-center text-on-surface-variant hover:text-primary transition-colors z-10"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      )}
                    </>
                  ) : (
                    isAdmin && order.status !== 'Baixada' && (
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          setAssigningOrder(order);
                          setIsAssignModalOpen(true);
                        }}
                        className="w-8 h-8 rounded-full border-2 border-dashed border-outline-variant flex items-center justify-center text-on-surface-variant/40 hover:text-primary hover:border-primary transition-colors"
                        title="Atribuir Responsáveis"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    )
                  )}
                </div>
              </div>

              {/* Informações Secundárias */}
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h4 className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-50 mb-1">Localização</h4>
                    <p className="text-sm font-bold text-on-surface truncate">{order.product_location || '-'}</p>
                  </div>
                  <div>
                    <h4 className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-50 mb-1">Data</h4>
                    <p className="text-sm font-bold text-on-surface">
                      {(() => {
                        const [y, m, d] = order.date.split('T')[0].split('-').map(Number);
                        return `${String(d).padStart(2, '0')}/${String(m).padStart(2, '0')}/${y}`;
                      })()}
                    </p>
                  </div>
                </div>

                {/* Barras de Progresso */}
                <div className="space-y-3 bg-surface-container-low/50 p-4 rounded-2xl border border-outline-variant/10">
                  {(() => {
                    const { separation, conference } = calculatePercentages(order.items);
                    return (
                      <>
                        <div className="space-y-1.5 flex-1">
                          <div className="flex items-center justify-between text-[10px] font-black uppercase tracking-widest">
                            <span className="text-primary truncate mr-1">Separação</span>
                            <span className="text-on-surface">{separation}%</span>
                          </div>
                          <div className="h-2 w-full bg-surface-container-high rounded-full overflow-hidden border border-outline-variant/5">
                            <motion.div 
                              initial={{ width: 0 }}
                              animate={{ width: `${separation}%` }}
                              transition={{ duration: 1, ease: 'easeOut' }}
                              className="h-full bg-primary rounded-full shadow-[0_0_10px_rgba(var(--primary-rgb),0.3)]"
                              style={{ minWidth: separation > 0 ? '4px' : '0' }}
                            />
                          </div>
                        </div>
                        <div className="space-y-1.5 flex-1">
                          <div className="flex items-center justify-between text-[10px] font-black uppercase tracking-widest">
                            <span className="text-blue-400 truncate mr-1">Conferência</span>
                            <span className="text-on-surface">{conference}%</span>
                          </div>
                          <div className="h-2 w-full bg-surface-container-high rounded-full overflow-hidden border border-outline-variant/5">
                            <motion.div 
                              initial={{ width: 0 }}
                              animate={{ width: `${conference}%` }}
                              transition={{ duration: 1, ease: 'easeOut', delay: 0.2 }}
                              className="h-full bg-blue-400 rounded-full shadow-[0_0_10px_rgba(96,165,250,0.3)]"
                              style={{ minWidth: conference > 0 ? '4px' : '0' }}
                            />
                          </div>
                        </div>
                      </>
                    );
                  })()}
                </div>

                  <div className="flex flex-wrap gap-2 pt-2">
                    {(() => {
                      const { separation, conference } = calculatePercentages(order.items);
                      const isSeparated = separation === 100;
                      const isConferred = order.conferred_by_name != null;
                      const isSigned = order.is_signed === true;
                      const isBaixada = order.status === 'Baixada';

                      return (
                        <>
                          <span className={cn(
                            "px-2.5 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest border transition-all",
                            isSeparated 
                              ? "bg-emerald-500/10 text-emerald-600 border-emerald-500/20" 
                              : "bg-surface-container-high text-on-surface-variant/40 border-outline-variant/10 opacity-50"
                          )}>
                            Separada
                          </span>
                          <span className={cn(
                            "px-2.5 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest border transition-all",
                            isConferred 
                              ? "bg-blue-500/10 text-blue-600 border-blue-500/20" 
                              : "bg-surface-container-high text-on-surface-variant/40 border-outline-variant/10 opacity-50"
                          )}>
                            Conferida
                          </span>
                          <span className={cn(
                            "px-2.5 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest border transition-all",
                            isSigned 
                              ? "bg-purple-500/10 text-purple-600 border-purple-500/20" 
                              : "bg-surface-container-high text-on-surface-variant/40 border-outline-variant/10 opacity-50"
                          )}>
                            Assinada
                          </span>
                          <span className={cn(
                            "px-2.5 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest border transition-all",
                            isBaixada 
                              ? "bg-amber-500 text-white border-amber-600 font-bold" 
                              : "bg-surface-container-high text-on-surface-variant/40 border-outline-variant/10 opacity-50"
                          )}>
                            Baixada
                          </span>
                        </>
                      );
                    })()}
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <span className={cn(
                    "px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest",
                    order.status === 'Separada' ? 'bg-emerald-500/10 text-emerald-500' : 
                    order.status === 'Conferida' ? 'bg-blue-500/10 text-blue-500' : 
                    order.status === 'Baixada' ? 'bg-amber-500 text-white shadow-lg shadow-amber-500/20 animate-pulse' :
                    order.status === 'Cancelada' ? 'bg-red-500/10 text-red-500 border border-red-500/20 font-black' :
                    'bg-amber-500/10 text-amber-500'
                  )}>
                    {order.status}
                  </span>
                  <span className="text-[10px] font-bold text-on-surface-variant opacity-40">
                    {order.items?.length || 0} Materiais
                  </span>
                </div>

                {/* Botão de Ação Inferior */}
                <div className="mt-auto space-y-2">
                  {(() => {
                    const { separation, conference } = calculatePercentages(order.items);
                    const isFullyComplete = separation === 100 && conference === 100;
                    const isSigned = order.is_signed === true;
                    const isBaixada = order.status === 'Baixada';
                    const isCancelled = order.status === 'Cancelada';

                    if (isCancelled) {
                      return (
                        <div className="w-full bg-red-500/10 text-red-500 py-3.5 px-4 rounded-xl flex items-center justify-center gap-2 border border-red-500/20 font-black text-xs uppercase tracking-wider">
                          <Ban className="w-4 h-4" />
                          OP Cancelada
                        </div>
                      );
                    }

                    if (isBaixada) {
                      return (
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            handleOpenOrder(order);
                            setModalMode('REVIEW');
                            setIsEditModalOpen(true);
                          }}
                          className="w-full bg-surface-container-high text-on-surface-variant p-4 rounded-2xl hover:bg-surface-container-highest transition-all flex items-center justify-center gap-2 font-bold group"
                        >
                          <span className="text-sm">Visualizar Detalhes</span>
                        </button>
                      );
                    }

                    if (isFullyComplete) {
                      const isConferred = !!order.conferred_by_name;

                      return (
                        <div className="grid grid-cols-1 gap-2">
                          <div className={cn(
                            "w-full flex flex-col items-center gap-0.5 px-6 py-3 rounded-2xl border shadow-lg transition-all mb-1",
                            isSigned 
                              ? "bg-emerald-500 text-white border-emerald-600 shadow-emerald-500/10" 
                              : isConferred
                                ? "bg-purple-600 text-white border-purple-700 shadow-purple-500/10"
                                : "bg-sky-600 text-white border-sky-700 shadow-sky-500/10"
                          )}>
                            <div className="flex items-center gap-2">
                               <CheckCircle2 className="w-4 h-4 fill-white/20" />
                               <span className="text-[11px] font-black uppercase tracking-[0.15em]">
                                 {isSigned ? 'OP ASSINADA' : isConferred ? 'Aguardando Assinatura' : 'Conferida OK (Pend. Conf. OP)'}
                               </span>
                            </div>
                            {order.conferred_by_name && (
                              <span className="text-[10px] font-bold opacity-90 truncate w-full text-center">Conferido por {order.conferred_by_name}</span>
                            )}
                          </div>

                          {/* Botão Assinar - Apenas se estiver conferido por alguém e não assinado */}
                          {isConferred && !isSigned && (
                            <button 
                              onClick={(e) => {
                                e.stopPropagation();
                                handleOpenOrder(order);
                                setModalMode('SIGN');
                                setIsEditModalOpen(true);
                              }}
                              className="w-full bg-purple-600 text-white p-3 rounded-xl hover:bg-purple-700 transition-all flex items-center justify-center gap-2 font-bold text-[11px] uppercase tracking-widest shadow-lg shadow-purple-500/20"
                            >
                              <Pen className="w-4 h-4" />
                              Assinar OP
                            </button>
                          )}

                          {/* Botão Conferir OP - se concluída nos itens mas sem o clique final no botão Conferir OP */}
                          {!isConferred && (
                            <button 
                              onClick={(e) => {
                                e.stopPropagation();
                                handleOpenOrder(order);
                                setModalMode('EDIT');
                                setIsEditModalOpen(true);
                              }}
                              className="w-full bg-sky-600 text-white p-3 rounded-xl hover:bg-sky-700 transition-all flex items-center justify-center gap-2 font-bold text-[11px] uppercase tracking-widest shadow-lg shadow-sky-500/20 animate-pulse"
                            >
                              <UserCheck className="w-4 h-4" />
                              Conferir OP
                            </button>
                          )}

                          {/* Botão Baixar - Apenas se assinada */}
                          {isAdmin && isSigned && (
                            <motion.button 
                              animate={{ scale: [1, 1.05, 1], opacity: [1, 0.8, 1] }}
                              transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
                              onClick={(e) => {
                                e.stopPropagation();
                                handleOpenOrder(order);
                                setModalMode('REVIEW');
                                setIsEditModalOpen(true);
                              }}
                              className="w-full bg-amber-500 text-white p-3 rounded-xl hover:bg-amber-600 transition-all flex items-center justify-center gap-2 font-bold text-[11px] uppercase tracking-widest shadow-lg shadow-amber-500/40 border-2 border-white/20"
                            >
                              <CheckCircle2 className="w-4 h-4" />
                              Baixar OP
                            </motion.button>
                          )}

                          {isAdmin && (
                            <div className="flex flex-col gap-2 mt-1">
                              {revertingId === order.id ? (
                                <div className="flex gap-2">
                                  <button 
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setRevertingId(null);
                                    }}
                                    className="flex-1 p-3 text-[10px] font-black uppercase tracking-widest text-on-surface-variant bg-surface-container-high rounded-xl border border-outline-variant/20"
                                  >
                                    Voltar
                                  </button>
                                  <button 
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      revertOrder(order.id);
                                    }}
                                    className="flex-[2] p-3 text-[10px] font-black uppercase tracking-widest text-white bg-error rounded-xl shadow-lg shadow-error/20 flex items-center justify-center gap-2"
                                  >
                                    <AlertCircle className="w-3 h-3" />
                                    {isSigned ? 'Reverter Aberto' : 'Reverter Pendente'}
                                  </button>
                                </div>
                              ) : (
                                <button 
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setRevertingId(order.id);
                                  }}
                                  className="w-full flex items-center justify-center gap-2 p-3 text-[10px] font-black uppercase tracking-widest text-on-surface-variant/40 hover:text-error transition-all hover:bg-error/5 rounded-xl border border-dashed border-outline-variant/10"
                                >
                                  <ArrowLeft className="w-3 h-3" />
                                  {isSigned ? 'Reverter para Aberto' : 'Reverter para Pendente'}
                                </button>
                              )}
                            </div>
                          )}
                        </div>
                      );
                    }

                    // Se não estiver completa e não estiver baixada:
                    return (
                      <div className="grid grid-cols-1 gap-2">
                        <button 
                          onClick={() => {
                            if (!order.sequence) return;
                            handleOpenOrder(order);
                            setModalMode('EDIT');
                            setIsEditModalOpen(true);
                          }}
                          disabled={!order.sequence}
                          className={cn(
                            "w-full p-4 rounded-2xl transition-all flex items-center justify-center gap-2 font-bold shadow-lg",
                            order.sequence 
                              ? "bg-primary text-white hover:opacity-90 shadow-primary/20" 
                              : "bg-surface-container-highest text-on-surface-variant/30 cursor-not-allowed grayscale"
                          )}
                        >
                          <Edit3 className="w-5 h-5" />
                          <span className="text-sm">Separar Materiais</span>
                        </button>
                        
                        {!order.sequence && (
                          <p className="text-[10px] font-bold text-error text-center bg-error/5 py-1 rounded-lg animate-pulse">
                            Aguardando Sequência
                          </p>
                        )}
                        
                        {(isConferente || isAdmin) && (
                          <button 
                            onClick={() => {
                              handleOpenOrder(order);
                              setModalMode('EDIT');
                              setIsEditModalOpen(true);
                            }}
                            className="w-full bg-surface-container-high text-on-surface-variant p-4 rounded-2xl hover:bg-emerald-500 hover:text-white border border-outline-variant/10 transition-all flex items-center justify-center gap-2 font-bold group/conf shadow-sm"
                          >
                            <UserCheck className="w-5 h-5 group-hover/conf:scale-110 transition-transform" />
                            <span className="text-sm">Conferir OP</span>
                          </button>
                        )}
                      </div>
                    );
                  })()}
                </div>
              </motion.div>
          ))}
        </div>
      )}

      {/* Edit Quantities Modal */}
      <AnimatePresence>
        {isEditModalOpen && editingOrder && (
          <div className="fixed inset-0 z-[100] bg-black/40 backdrop-blur-sm flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-surface-container-lowest w-full max-w-4xl max-h-[95vh] md:max-h-[90vh] rounded-2xl md:rounded-[40px] shadow-2xl overflow-hidden flex flex-col"
            >
              <div className="p-4 md:p-8 border-b border-outline-variant/10 flex items-center justify-between">
                <div className="flex items-center gap-3 md:gap-4">
                  <div className="w-10 h-10 md:w-12 md:h-12 bg-primary/10 rounded-xl md:rounded-2xl flex items-center justify-center text-primary">
                    <ClipboardList className="w-5 h-5 md:w-6 md:h-6" />
                  </div>
                  <div>
                    <h3 className="text-lg md:text-2xl font-headline font-black text-on-surface">
                      {modalMode === 'SIGN' ? 'Assinatura Eletrônica' : modalMode === 'REVIEW' ? 'Revisão da OP' : 'Lançar Separação'}
                    </h3>
                    <p className="text-xs md:text-sm text-on-surface-variant">OP #{editingOrder.order_number}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => setIsCalculatorOpen(!isCalculatorOpen)}
                    type="button"
                    className={cn(
                      "p-1.5 md:p-2 rounded-full transition-all flex items-center justify-center gap-1 cursor-pointer",
                      isCalculatorOpen 
                        ? "bg-primary text-white shadow-md shadow-primary/20 scale-105" 
                        : "hover:bg-surface-container-high text-on-surface-variant"
                    )}
                    title="Abrir Calculadora"
                  >
                    <Calculator className="w-5 h-5 md:w-6 md:h-6" />
                  </button>
                  <button 
                    onClick={() => setIsEditModalOpen(false)}
                    className="p-1.5 md:p-2 hover:bg-surface-container-high rounded-full transition-colors"
                  >
                    <ArrowLeft className="w-5 h-5 md:w-6 md:h-6" />
                  </button>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-4 md:p-8">
                {error && (
                  <motion.div 
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-error/10 text-error p-4 rounded-2xl flex items-center gap-3 mb-6 border border-error/20"
                  >
                    <AlertCircle className="w-5 h-5 shrink-0" />
                    <p className="text-sm font-bold leading-tight">{error}</p>
                    <button onClick={() => setError(null)} className="ml-auto p-1 hover:bg-error/10 rounded-lg">
                      <X className="w-4 h-4" />
                    </button>
                  </motion.div>
                )}

                {modalMode === 'EDIT' && (
                  <>
                    {/* Campo PI */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                      <div className="p-4 md:p-6 bg-surface-container-low rounded-[24px] md:rounded-[32px] border border-outline-variant/10">
                        <label className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-60 mb-2 md:mb-3 block ml-1">Processos Industriais (PI)</label>
                        <div className="flex gap-2 mb-3 md:mb-4">
                          <input 
                            type="text"
                            value={currentPI}
                            disabled={isViewer || !(isAdmin || isSuperAdmin || userCategory === 'Ventisol' || userCategory === 'Ventisol + Conferente')}
                            onChange={(e) => setCurrentPI(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && !isViewer && (isAdmin || isSuperAdmin || userCategory === 'Ventisol' || userCategory === 'Ventisol + Conferente') && handleAddPI()}
                            placeholder="Número da PI..."
                            className="flex-1 bg-surface-container-highest border-0 rounded-xl md:rounded-2xl px-4 md:px-5 py-3 md:py-4 focus:ring-2 focus:ring-primary outline-none transition-all font-bold text-sm disabled:opacity-50"
                          />
                          <button 
                            onClick={handleAddPI}
                            disabled={isViewer || !(isAdmin || isSuperAdmin || userCategory === 'Ventisol' || userCategory === 'Ventisol + Conferente')}
                            className="w-12 h-12 bg-primary text-white rounded-xl md:rounded-2xl flex items-center justify-center shadow-lg shadow-primary/20 hover:opacity-90 active:scale-95 transition-all outline-none disabled:opacity-50"
                          >
                            <Plus className="w-5 h-5 md:w-6 md:h-6" />
                          </button>
                        </div>
                        
                        <div className="flex flex-wrap gap-2">
                          {editingOrder.pis?.map(pi => (
                            <div key={pi} className="bg-primary/10 text-primary px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-2 border border-primary/20">
                              {pi}
                              {(!isViewer && (isAdmin || isSuperAdmin || userCategory === 'Ventisol' || userCategory === 'Ventisol + Conferente')) && (
                                <button onClick={() => handleRemovePI(pi)} className="hover:text-error transition-colors">
                                  <X className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Sequência (Admin) */}
                      <div className={cn(
                        "p-4 md:p-6 rounded-[24px] md:rounded-[32px] border transition-all flex flex-col justify-between",
                        isAdmin ? "bg-amber-500/5 border-amber-500/20" : "bg-surface-container-low border-outline-variant/10 opacity-50"
                      )}>
                        <div>
                          <label className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-60 mb-2 md:mb-3 block ml-1">Sequência de Separação</label>
                          <div className="flex items-center gap-4">
                            <input 
                              type="number"
                              value={editingOrder.sequence || ''}
                              disabled={!isAdmin || isViewer}
                              onChange={(e) => {
                                const val = e.target.value === '' ? null : parseInt(e.target.value);
                                setEditingOrder({ ...editingOrder, sequence: val });
                              }}
                              placeholder="Ex: 1"
                              className="flex-1 bg-surface-container-highest border-0 rounded-xl md:rounded-2xl px-5 py-4 focus:ring-2 focus:ring-amber-500 outline-none transition-all font-black text-xl disabled:opacity-50 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                            />
                            <div className={cn(
                              "w-12 h-12 rounded-xl flex items-center justify-center",
                              isAdmin ? "bg-amber-500/10 text-amber-600" : "bg-surface-container-high text-on-surface-variant/20"
                            )}>
                              <Package className="w-6 h-6" />
                            </div>
                          </div>
                        </div>
                        {!isAdmin && (
                          <p className="text-[9px] font-bold text-on-surface-variant/40 mt-2 ml-1 italic">* Edição restrita a administradores</p>
                        )}
                      </div>
                    </div>

                    <div className="bg-surface-container-high/30 overflow-hidden rounded-2xl md:rounded-[32px] border border-outline-variant/10 shadow-inner">
                    {/* Cabeçalho Desktop */}
                    <div className="hidden md:grid grid-cols-[1fr,120px,100px,100px,80px,50px] bg-surface-container-high px-6 py-4">
                      <div className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-60">Material / Código</div>
                      <div className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-60 text-center">Local</div>
                      <div className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-60 text-center">Planejado</div>
                      <div className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-60 text-center">Separado</div>
                      <div className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-60 text-center">Dif.</div>
                    </div>

                    <div className="divide-y divide-outline-variant/10">
                      {editingOrder.items?.map((item, idx) => (
                        <div key={idx} className="p-3 md:p-4 md:px-6 md:py-3 hover:bg-surface-container-low/50 transition-colors grid grid-cols-1 md:grid-cols-[1fr,120px,100px,100px,80px,50px] items-center gap-3 md:gap-0">
                          {/* Material Info */}
                          <div className="min-w-0">
                            {/* Desktop: Descrição > Código */}
                            <div className="hidden md:block">
                              <p className="text-sm font-bold text-on-surface truncate pr-4">{item.description}</p>
                              <p className="text-[10px] text-on-surface-variant font-bold uppercase opacity-60">{item.code || 'S/ COD'}</p>
                            </div>
                            {/* Mobile: Código (Ênfase) > Descrição */}
                            <div className="md:hidden">
                              <p className="text-lg font-black text-primary leading-tight mb-0.5">{item.code || 'SEM CÓDIGO'}</p>
                              <div className="flex items-center gap-2 mb-1">
                                <p className="text-[11px] font-medium text-on-surface-variant line-clamp-2 leading-relaxed italic">{item.description}</p>
                                {item.location && (
                                  <span className={cn(
                                    "shrink-0 text-[10px] font-black px-2 py-0.5 rounded-md",
                                    isItemRestricted(item) ? "bg-error/10 text-error" : "bg-amber-500/10 text-amber-600"
                                  )}>
                                    LO: {item.location} {isItemRestricted(item) && '🔒'}
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>

                          {/* Local Column (Desktop) */}
                          <div className="hidden md:flex justify-center">
                            <span className={cn(
                              "text-[10px] font-black px-2.5 py-1 rounded-lg border",
                              isItemRestricted(item) 
                                ? "bg-error/10 text-error border-error/20" 
                                : "bg-amber-500/10 text-amber-600 border-amber-500/10"
                            )}>
                              {item.location || '-'} {isItemRestricted(item) && '🔒'}
                            </span>
                          </div>

                          {/* Colunas de Quantidade (Responsivas) */}
                          <div className="grid grid-cols-3 md:contents items-center bg-surface-container-low md:bg-transparent p-3 md:p-0 rounded-2xl md:rounded-none border border-outline-variant/5 md:border-none">
                            <div className="flex flex-col items-center md:items-center">
                              <span className="md:hidden text-[9px] font-black uppercase text-on-surface-variant/40 mb-1">Plan.</span>
                              <p className="font-bold text-on-surface text-sm md:text-base">{item.planned_quantity}</p>
                            </div>
                            
                            <div className="flex flex-col items-center md:items-center">
                              <span className="md:hidden text-[9px] font-black uppercase text-on-surface-variant/40 mb-1">Sep.</span>
                              <input 
                                type="number"
                                disabled={
                                  isViewer || 
                                  editingOrder.status === 'Baixada' || 
                                  isItemRestricted(item) ||
                                  !(isAdmin || isSuperAdmin || userCategory === 'Ventisol' || userCategory === 'Ventisol + Conferente')
                                }
                                className={cn(
                                  "w-14 md:w-16 bg-surface-container-high md:bg-surface-container-low text-center font-black p-2 rounded-xl outline-none focus:ring-2 ring-primary/30 text-sm disabled:opacity-50 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none",
                                  item.quantity !== null && (item.quantity as number) < item.planned_quantity && "ring-2 ring-error/50 text-error bg-error/5",
                                  isItemRestricted(item) && "opacity-20 grayscale"
                                )}
                                value={item.quantity === null ? '' : item.quantity}
                                onChange={(e) => handleEditItemQuantity(idx, parseInt(e.target.value))}
                              />
                            </div>

                            <div className="flex flex-col items-center md:items-center">
                              <span className="md:hidden text-[9px] font-black uppercase text-on-surface-variant/40 mb-1">Dif.</span>
                              <span className={cn(
                                "text-sm md:text-xs font-black px-2 py-0.5 rounded-md",
                                item.quantity === null 
                                  ? "bg-surface-container-high text-on-surface-variant/30"
                                  : ((item.quantity ?? 0) - item.planned_quantity) >= 0 
                                    ? "bg-emerald-500/10 text-emerald-500" 
                                    : "bg-amber-500/10 text-amber-500"
                              )}>
                                {item.quantity === null ? '-' : (item.quantity ?? 0) - item.planned_quantity}
                              </span>
                            </div>
                          </div>

                          {/* Conferido Check Column */}
                          <div className="flex justify-center">
                            <button 
                              onClick={() => handleToggleItemConferred(idx)}
                              disabled={
                                isViewer || 
                                editingOrder.status === 'Baixada' || 
                                isItemRestricted(item) ||
                                !(isAdmin || isSuperAdmin || isConferente || userCategory === 'Ventisol + Conferente' || userCategory === 'Conferente')
                              }
                              className={cn(
                                "w-8 h-8 rounded-full flex items-center justify-center transition-all",
                                item.is_conferred 
                                  ? "bg-emerald-500 text-white shadow-lg shadow-emerald-500/20" 
                                  : "bg-surface-container-high text-on-surface-variant/30 hover:bg-emerald-500/10 hover:text-emerald-500 border border-outline-variant/10",
                                isItemRestricted(item) && "opacity-20 grayscale"
                              )}
                              title={(isAdmin || isSuperAdmin || isConferente || userCategory === 'Ventisol + Conferente' || userCategory === 'Conferente') && !isViewer && !isItemRestricted(item) ? "Alternar Conferência" : "Sem permissão"}
                            >
                              <UserCheck className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Observações e Fotos */}
                  <div className="mt-8 space-y-6">
                      <div className="bg-surface-container-low p-6 rounded-[32px] border border-outline-variant/10">
                        <label className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-60 mb-3 block ml-1">Observação da Separação</label>
                        <textarea 
                          value={editingOrder.observation || ''}
                          disabled={isViewer || !(isAdmin || isSuperAdmin || userCategory === 'Ventisol' || userCategory === 'Ventisol + Conferente')}
                          onChange={(e) => setEditingOrder({ ...editingOrder, observation: e.target.value })}
                          placeholder="Alguma observação sobre esta separação?"
                          className="w-full bg-surface-container-highest border-0 rounded-2xl px-5 py-4 focus:ring-2 focus:ring-primary outline-none transition-all font-medium text-sm min-h-[100px] resize-none disabled:opacity-50"
                        />
                      </div>

                      <div className="bg-surface-container-low p-6 rounded-[32px] border border-outline-variant/10">
                        <div className="flex items-center justify-between mb-4">
                          <label className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-60 ml-1">Fotos da Separação</label>
                          <label className={cn(
                            "px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2 transition-all shadow-lg shadow-primary/10",
                            (isViewer || !(isAdmin || isSuperAdmin || userCategory === 'Ventisol' || userCategory === 'Ventisol + Conferente'))
                              ? "bg-surface-container-high text-on-surface-variant/40 cursor-not-allowed"
                              : "cursor-pointer bg-primary text-white hover:opacity-90"
                          )}>
                            <Camera className="w-3 h-3" />
                            Adicionar Fotos
                            <input 
                              type="file" 
                              multiple 
                              accept="image/*" 
                              capture="environment"
                              className="hidden" 
                              onChange={handlePhotoUpload} 
                              disabled={uploadingPhotos || isViewer || !(isAdmin || isSuperAdmin || userCategory === 'Ventisol' || userCategory === 'Ventisol + Conferente')}
                            />
                          </label>
                        </div>

                        {uploadingPhotos && (
                          <div className="flex items-center gap-2 text-primary font-bold text-xs mb-4 animate-pulse">
                            <Loader2 className="w-4 h-4 animate-spin" />
                            Carregando fotos...
                          </div>
                        )}

                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                          {editingOrder.photos?.map((url, i) => (
                            <div key={i} className="relative aspect-square rounded-2xl overflow-hidden border border-outline-variant/20 group">
                              <img src={url} alt={`Foto ${i + 1}`} className="w-full h-full object-cover" />
                              <button 
                                onClick={() => handleRemovePhoto(url)}
                                className="absolute top-2 right-2 p-1.5 bg-error text-white rounded-lg opacity-0 group-hover:opacity-100 transition-opacity shadow-lg"
                              >
                                <X className="w-3 h-3" />
                              </button>
                              <a 
                                href={url} 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="absolute bottom-2 right-2 p-1.5 bg-surface-container-lowest text-on-surface rounded-lg opacity-0 group-hover:opacity-100 transition-opacity shadow-lg"
                              >
                                <Eye className="w-3 h-3" />
                              </a>
                            </div>
                          ))}
                          {(!editingOrder.photos || editingOrder.photos.length === 0) && (
                            <div className="col-span-full py-8 border-2 border-dashed border-outline-variant/20 rounded-2xl flex flex-col items-center justify-center text-on-surface-variant/40">
                              <ImageIcon className="w-8 h-8 mb-2 opacity-20" />
                              <p className="text-[10px] font-bold uppercase tracking-widest">Nenhuma foto anexada</p>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </>
                )}

                {modalMode === 'REVIEW' && (
                  <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
                    {/* Tabela Cabeçalho */}
                    <div className="bg-surface-container-high/40 rounded-[32px] border border-outline-variant/10 overflow-hidden">
                      <div className="bg-surface-container-high px-6 py-3 border-b border-outline-variant/10">
                        <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-on-surface">Dados do Cabeçalho</h4>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 p-6 gap-6">
                        <div className="space-y-1">
                          <p className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-60">Fornecedor</p>
                          <p className="font-bold text-on-surface">{editingOrder.supplier_name}</p>
                        </div>
                        <div className="space-y-1">
                          <p className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-60">Localização</p>
                          <p className="font-bold text-on-surface">{editingOrder.product_location || 'N/A'}</p>
                        </div>
                        <div className="space-y-1">
                          <p className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-60">Data da OP</p>
                          <p className="font-bold text-on-surface">{new Date(editingOrder.date).toLocaleDateString('pt-BR')}</p>
                        </div>
                        <div className="space-y-1">
                          <p className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-60">Conferido Por</p>
                          <p className="font-bold text-emerald-500">{editingOrder.conferred_by_name || 'PENDENTE'}</p>
                        </div>
                        <div className="space-y-1">
                          <p className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-60">Assinado Por</p>
                          <p className="font-bold text-purple-500">{editingOrder.signed_by_name || 'PENDENTE'}</p>
                        </div>
                        <div className="space-y-1">
                          <p className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-60">Status Atual</p>
                          <span className={cn(
                            "inline-block px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest",
                            editingOrder.status === 'Baixada' ? "bg-amber-500 text-white" : "bg-primary/10 text-primary"
                          )}>
                            {editingOrder.status}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Tabela Itens Detalhada */}
                    <div className="bg-surface-container-high/40 rounded-[32px] border border-outline-variant/10 overflow-hidden">
                      <div className="bg-surface-container-high px-6 py-3 border-b border-outline-variant/10">
                        <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-on-surface">Itens da Operação</h4>
                      </div>
                      <div className="overflow-x-auto">
                        <table className="w-full text-left border-collapse">
                          <thead>
                            <tr className="bg-surface-container-low/50">
                              <th className="px-6 py-4 text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-60">Cód/Material</th>
                              <th className="px-4 py-4 text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-60 text-center">Local</th>
                              <th className="px-4 py-4 text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-60 text-center">Plan.</th>
                              <th className="px-4 py-4 text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-60 text-center">Sep.</th>
                              <th className="px-4 py-4 text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-60 text-center">Dif.</th>
                              <th className="px-6 py-4 text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-60 text-center">Conf.</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-outline-variant/5">
                            {editingOrder.items?.map((item, idx) => (
                              <tr key={idx} className="hover:bg-surface-container-low/30 transition-colors">
                                <td className="px-6 py-4">
                                  <p className="text-sm font-black text-on-surface whitespace-nowrap">{item.code || '-'}</p>
                                  <p className="text-[11px] font-medium text-on-surface-variant leading-tight">{item.description}</p>
                                </td>
                                <td className="px-4 py-4 text-center">
                                  <span className="text-[10px] font-black text-amber-600 bg-amber-500/10 px-2 py-1 rounded-md">
                                    {item.location || '-'}
                                  </span>
                                </td>
                                <td className="px-4 py-4 text-center text-sm font-bold text-on-surface">{item.planned_quantity}</td>
                                <td className="px-4 py-4 text-center text-sm font-black text-primary">{item.quantity ?? 0}</td>
                                <td className="px-4 py-4 text-center">
                                  <span className={cn(
                                    "text-[11px] font-black px-2 py-0.5 rounded-md",
                                    ((item.quantity ?? 0) - item.planned_quantity) >= 0 ? "bg-emerald-500/10 text-emerald-500" : "bg-amber-500/10 text-amber-500"
                                  )}>
                                    {(item.quantity ?? 0) - item.planned_quantity}
                                  </span>
                                </td>
                                <td className="px-6 py-4 text-center">
                                  {item.is_conferred ? (
                                    <div className="flex justify-center"><CheckCircle2 className="w-4 h-4 text-emerald-500" /></div>
                                  ) : (
                                    <div className="flex justify-center"><AlertCircle className="w-4 h-4 text-amber-500 opacity-50" /></div>
                                  )}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
                      <div className="p-4 bg-surface-container-low rounded-2xl border border-outline-variant/10 shadow-sm">
                        <p className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-60 mb-1">Total Planejado</p>
                        <p className="text-xl font-headline font-black text-on-surface">
                          {editingOrder.items?.reduce((acc, i) => acc + i.planned_quantity, 0)}
                        </p>
                      </div>
                      <div className="p-4 bg-surface-container-low rounded-2xl border border-outline-variant/10 shadow-sm">
                        <p className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-60 mb-1">Total Separado</p>
                        <p className="text-xl font-headline font-black text-primary">
                          {editingOrder.items?.reduce((acc, i) => acc + (i.quantity ?? 0), 0)}
                        </p>
                      </div>
                      <div className="p-4 bg-surface-container-low rounded-2xl border border-outline-variant/10 shadow-sm">
                        <p className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-60 mb-1">Diferença Total</p>
                        <p className={cn(
                          "text-xl font-headline font-black",
                          (editingOrder.items?.reduce((acc, i) => acc + (i.quantity ?? 0), 0) || 0) - (editingOrder.items?.reduce((acc, i) => acc + i.planned_quantity, 0) || 0) >= 0 
                            ? "text-emerald-500" 
                            : "text-amber-500"
                        )}>
                          {(editingOrder.items?.reduce((acc, i) => acc + (i.quantity ?? 0), 0) || 0) - (editingOrder.items?.reduce((acc, i) => acc + i.planned_quantity, 0) || 0)}
                        </p>
                      </div>
                    </div>

                    {/* PIs e Observações no Review */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      {editingOrder.pis && editingOrder.pis.length > 0 && (
                        <div className="bg-surface-container-high/20 rounded-[32px] border border-outline-variant/10 p-6">
                          <p className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-60 mb-3">PIs Vinculadas</p>
                          <div className="flex flex-wrap gap-2">
                            {editingOrder.pis.map(pi => (
                              <span key={pi} className="bg-primary/5 text-primary px-3 py-1.5 rounded-xl text-xs font-bold border border-primary/10">
                                PI #{pi}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                      {editingOrder.observation && (
                        <div className="bg-surface-container-high/20 rounded-[32px] border border-outline-variant/10 p-6">
                          <p className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-60 mb-3">Observação</p>
                          <p className="text-sm text-on-surface font-medium leading-relaxed italic">"{editingOrder.observation}"</p>
                        </div>
                      )}
                    </div>

                    {/* Fotos no Review */}
                    {editingOrder.photos && editingOrder.photos.length > 0 && (
                      <div className="bg-surface-container-high/20 rounded-[32px] border border-outline-variant/10 p-6">
                        <p className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-60 mb-4">Fotos da Separação</p>
                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
                          {editingOrder.photos.map((url, i) => (
                            <a key={i} href={url} target="_blank" rel="noopener noreferrer" className="aspect-square rounded-2xl overflow-hidden border border-outline-variant/10 hover:ring-2 ring-primary transition-all">
                              <img src={url} alt={`Foto ${i + 1}`} className="w-full h-full object-cover" />
                            </a>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Exibição da Assinatura no Review se existir */}
                    {editingOrder.is_signed && (
                       <div className="bg-surface-container-high/20 rounded-[32px] border border-outline-variant/10 p-6 flex flex-col items-center gap-4">
                          <p className="text-[10px] font-black uppercase tracking-widest text-on-surface-variant opacity-60">Assinatura Eletrônica Registrada</p>
                          <div className="bg-surface-container-lowest p-4 rounded-2xl w-full flex justify-center">
                            <img src={editingOrder.signature_url} alt="Assinatura" className="h-32 object-contain" style={{ filter: isDarkMode ? 'brightness(0) invert(1)' : 'brightness(0)' }} />
                          </div>
                          <div className="text-center">
                            <p className="text-sm font-bold text-on-surface italic">Assinado por: {editingOrder.signed_by_name}</p>
                            <p className="text-[10px] font-mono text-on-surface-variant opacity-50 uppercase">{editingOrder.signed_at && new Date(editingOrder.signed_at).toLocaleString()}</p>
                          </div>
                       </div>
                    )}
                  </div>
                )}
                {/* Área de Assinatura Eletrônica Manuscrita - Oculta no modo EDIT conforme solicitado */}
                {modalMode === 'SIGN' && (
                  <div className="pt-6 border-t border-outline-variant/10 mt-0">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <Pen className="w-4 h-4 text-primary" />
                          <h4 className="text-[11px] font-black uppercase tracking-[0.2em] text-on-surface">Assinatura Eletrônica Manuscrita</h4>
                        </div>
                        <p className="text-[10px] text-on-surface-variant opacity-60 font-medium">Validado eletronicamente conforme diretrizes de conferência.</p>
                      </div>
                      {!editingOrder.is_signed && (
                        <button 
                          type="button"
                          onClick={() => sigCanvas.current?.clear()}
                          className="text-[10px] font-black uppercase tracking-widest text-error flex items-center gap-2 hover:bg-error/5 px-4 py-2 rounded-xl transition-colors self-start md:self-center"
                        >
                          <Eraser className="w-4 h-4" />
                          Limpar Área
                        </button>
                      )}
                    </div>

                    <div className="bg-surface-container-high rounded-[40px] border border-outline-variant/20 p-6 shadow-inner overflow-hidden">
                      {editingOrder.is_signed ? (
                        <div className="w-full flex flex-col items-center justify-center py-6 bg-surface-container-lowest rounded-3xl relative group border border-outline-variant/5">
                          <img 
                            src={editingOrder.signature_url} 
                            alt="Assinatura Manuscrita" 
                            className="max-h-40 object-contain" style={{ filter: isDarkMode ? 'brightness(0) invert(1)' : 'brightness(0)' }}
                          />
                          <div className="mt-4 flex flex-col items-center">
                             <div className="flex items-center gap-2 text-emerald-500 mb-1">
                               <CheckCircle2 className="w-4 h-4" />
                               <span className="text-[11px] font-black uppercase tracking-widest">Documento Assinado</span>
                             </div>
                             <p className="text-[12px] text-on-surface font-bold uppercase tracking-widest mb-1 text-center italic">
                               Assinado por: {editingOrder.signed_by_name}
                             </p>
                             <p className="text-[9px] text-on-surface-variant font-mono opacity-50 uppercase tracking-tighter">
                               HASH: {editingOrder.id.substring(0, 12).toUpperCase()} / DT: {editingOrder.signed_at ? new Date(editingOrder.signed_at).toLocaleString() : new Date().toLocaleString()}
                             </p>
                          </div>
                        </div>
                      ) : (
                        <div className="w-full bg-surface-container-lowest rounded-3xl border-2 border-dashed border-outline-variant/30 overflow-hidden touch-none relative">
                          <SignatureCanvas 
                            ref={sigCanvas}
                            penColor={isDarkMode ? "#fff" : "#000"}
                            canvasProps={{
                              className: "signature-canvas w-full h-48 cursor-crosshair",
                            }}
                          />
                          <div className="absolute inset-0 pointer-events-none border-[12px] border-white/50 opacity-10"></div>
                          <div className="bg-surface-container-low p-3 text-center border-t border-outline-variant/10">
                            <p className="text-[10px] font-bold text-primary uppercase tracking-[0.1em] flex items-center justify-center gap-2">
                              <Pen className="w-3 h-3" />
                              Assine no campo acima utilizando o dedo ou caneta stylus
                            </p>
                          </div>
                        </div>
                      )}
                    </div>
                    
                    <div className="mt-4 px-2">
                      <p className="text-[9px] leading-relaxed text-on-surface-variant opacity-40 text-center font-medium">
                        Ao assinar este documento, você confirma a integridade dos itens conferidos e aceita os termos de responsabilidade técnica pela separação dos materiais descritos nesta Ordem de Produção.
                      </p>
                    </div>
                  </div>
                )}
              </div>

                  <div className="p-4 md:p-8 border-t border-outline-variant/10 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 md:gap-3">
                <div className="flex flex-col md:flex-row items-stretch md:items-center gap-4">
                  {modalMode === 'EDIT' && editingOrder.conferred_by_name && (
                    <div className="flex items-center gap-2 text-emerald-500 bg-emerald-500/10 px-4 py-2 rounded-2xl border border-emerald-500/20 animate-in fade-in zoom-in duration-300">
                      <UserCheck className="w-5 h-5" />
                      <div>
                        <p className="text-xs font-black uppercase tracking-widest leading-none mb-1">Conferido por</p>
                        <p className="text-sm font-bold">{editingOrder.conferred_by_name}</p>
                      </div>
                    </div>
                  )}

                  {modalMode === 'SIGN' && !editingOrder.is_signed && (
                    <button 
                      onClick={signOrder}
                      disabled={isProcessing}
                      className="px-8 py-3 bg-purple-600 text-white rounded-2xl font-bold flex items-center justify-center gap-2 hover:opacity-90 transition-all shadow-lg shadow-purple-500/20 w-full md:w-auto"
                    >
                      {isProcessing ? <Loader2 className="w-5 h-5 animate-spin" /> : <Pen className="w-5 h-5" />}
                      Salvar Assinatura
                    </button>
                  )}
                  {modalMode === 'REVIEW' && isAdmin && editingOrder.status !== 'Baixada' && (
                    isBaixarConfirming ? (
                      <div className="flex flex-col sm:flex-row gap-2 w-full md:w-auto">
                        <button 
                          onClick={() => setIsBaixarConfirming(false)}
                          className="px-6 py-3 rounded-2xl font-bold text-on-surface-variant bg-surface-container-high hover:bg-surface-container-highest transition-colors w-full sm:w-auto"
                        >
                          Cancelar
                        </button>
                        <button 
                          onClick={() => baixarOrder(editingOrder.id)}
                          disabled={isProcessing}
                          className="px-8 py-3 bg-amber-600 text-white rounded-2xl font-black uppercase tracking-widest flex items-center justify-center gap-3 hover:bg-amber-700 transition-all shadow-xl shadow-amber-500/20 w-full sm:w-auto"
                        >
                          {isProcessing ? <Loader2 className="w-5 h-5 animate-spin" /> : <CheckCircle2 className="w-5 h-5" />}
                          Confirmar Agora
                        </button>
                      </div>
                    ) : (
                      <button 
                        onClick={() => setIsBaixarConfirming(true)}
                        disabled={isProcessing}
                        className="px-12 py-3 bg-amber-500 text-white rounded-2xl font-black uppercase tracking-widest flex items-center justify-center gap-3 hover:bg-amber-600 transition-all shadow-xl shadow-amber-500/20 animate-in fade-in zoom-in duration-500 w-full md:w-auto"
                      >
                        {isProcessing ? <Loader2 className="w-6 h-6 animate-spin" /> : <CheckCircle2 className="w-6 h-6" />}
                        Confirmar Baixa de OP
                      </button>
                    )
                  )}
                </div>

                <div className="flex flex-col md:flex-row gap-3 w-full md:w-auto items-center">
                  {modalMode === 'EDIT' && editingOrder.status !== 'Baixada' && (
                    <>
                      {/* Botão Salvar Separação */}
                      <button 
                        onClick={updateOrder}
                        disabled={isProcessing}
                        className="px-8 py-3 bg-primary text-white rounded-2xl font-bold flex items-center justify-center gap-2 hover:opacity-90 transition-all shadow-lg shadow-primary/20 w-full md:w-auto text-sm"
                      >
                        {isProcessing ? <Loader2 className="w-5 h-5 animate-spin" /> : <Package className="w-5 h-5" />}
                        Salvar Separação
                      </button>

                      {/* Botão Conferir OP - ao lado de Salvar Separação */}
                      {!editingOrder.conferred_by_name && (isAdmin || isSuperAdmin || isConferente || userCategory === 'Conferente' || userCategory === 'Ventisol + Conferente') && (() => {
                        const { separation, conference } = calculatePercentages(editingOrder.items);
                        const canConfer = separation === 100 && conference === 100;

                        return (
                          <div className="flex flex-col gap-1 w-full md:w-auto">
                            {isConferConfirming ? (
                              <div className="flex gap-2 w-full md:w-auto">
                                <button 
                                  onClick={() => setIsConferConfirming(false)}
                                  className="px-4 py-3 rounded-2xl font-bold text-on-surface-variant bg-surface-container-high hover:bg-surface-container-highest transition-colors w-full md:w-auto text-sm"
                                >
                                  Voltar
                                </button>
                                <button 
                                  onClick={conferOrder}
                                  disabled={isProcessing}
                                  className="px-6 py-3 rounded-2xl font-bold bg-emerald-600 text-white shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2 hover:bg-emerald-700 transition-colors w-full md:w-auto text-sm"
                                >
                                  {isProcessing ? <Loader2 className="w-5 h-5 animate-spin" /> : <CheckCircle2 className="w-5 h-5" />}
                                  Confirmar
                                </button>
                              </div>
                            ) : (
                              <button 
                                onClick={() => setIsConferConfirming(true)}
                                disabled={isProcessing || !canConfer}
                                className={cn(
                                  "px-6 py-3 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg text-sm w-full md:w-auto",
                                  canConfer 
                                    ? "bg-emerald-500 text-white shadow-emerald-500/20 hover:opacity-90 cursor-pointer" 
                                    : "bg-surface-container-high text-on-surface-variant/40 shadow-none grayscale cursor-not-allowed"
                                )}
                                title={canConfer ? "Finalizar conferência da OP" : "Todos os itens devem estar 100% separados e conferidos"}
                              >
                                {isProcessing ? <Loader2 className="w-5 h-5 animate-spin" /> : <UserCheck className="w-5 h-5" />}
                                Conferir OP
                              </button>
                            )}
                            {!canConfer && (
                              <p className="text-[8px] font-bold text-amber-500 uppercase tracking-wider animate-pulse text-center">
                                * Requer 100% nos Itens
                              </p>
                            )}
                          </div>
                        );
                      })()}
                    </>
                  )}
                  {editingOrder.status === 'Baixada' && (
                    <div className="bg-amber-100 text-amber-700 px-6 py-3 rounded-xl font-bold border border-amber-200 text-sm flex items-center gap-2">
                       <CheckCircle2 className="w-5 h-5" />
                       Esta OP está baixada e não permite alterações.
                    </div>
                  )}
                  <button 
                    onClick={() => setIsEditModalOpen(false)}
                    className="px-6 py-4 md:py-3 rounded-2xl font-bold text-on-surface-variant hover:bg-surface-container-high w-full md:w-auto text-sm"
                  >
                    Fechar
                  </button>
                </div>
              </div>
            </motion.div>

            {/* Calculadora Flutuante */}
            <AnimatePresence>
              {isCalculatorOpen && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9, y: 20 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.9, y: 20 }}
                  transition={{ duration: 0.2 }}
                  className="absolute right-4 bottom-4 md:right-8 md:bottom-8 z-[110] bg-surface-container-lowest border border-outline-variant/20 shadow-2xl rounded-[32px] p-5 w-80 select-none flex flex-col gap-4 max-w-[90vw] animate-in fade-in zoom-in duration-200"
                >
                  <div className="flex items-center justify-between border-b border-outline-variant/10 pb-3">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 bg-primary/10 rounded-xl flex items-center justify-center text-primary">
                        <Calculator className="w-4 h-4" />
                      </div>
                      <span className="text-sm font-headline font-black text-on-surface">Calculadora</span>
                    </div>
                    <button 
                      onClick={() => setIsCalculatorOpen(false)}
                      type="button"
                      className="p-1 hover:bg-surface-container-high rounded-full transition-colors"
                    >
                      <X className="w-4 h-4 text-on-surface-variant" />
                    </button>
                  </div>

                  {/* Visor */}
                  <div className="bg-surface-container-high/40 border border-outline-variant/10 rounded-2xl p-4 flex flex-col justify-between align-end shadow-inner h-24">
                    <div className="font-mono text-xs text-on-surface-variant/60 text-right overflow-x-auto whitespace-nowrap scrollbar-none select-text pr-1 min-h-[16px]">
                      {calcExpression || '0'}
                    </div>
                    <div className="font-mono text-2xl font-black text-on-surface text-right overflow-x-auto whitespace-nowrap scrollbar-none select-text pr-1 min-h-[32px]">
                      {calcResult || calcExpression || '0'}
                    </div>
                  </div>

                  {/* Teclado */}
                  <div className="grid grid-cols-4 gap-2 font-mono">
                    <button 
                      onClick={handleCalcClear}
                      type="button"
                      className="col-span-1 bg-error/10 text-error hover:bg-error/20 font-black h-11 rounded-xl text-center flex items-center justify-center text-sm transition-all cursor-pointer"
                    >
                      C
                    </button>
                    <button 
                      onClick={() => handleCalcKeyPress('(')}
                      type="button"
                      className="bg-surface-container-high text-on-surface hover:bg-surface-container-highest font-bold h-11 rounded-xl text-center flex items-center justify-center text-sm transition-all cursor-pointer"
                    >
                      (
                    </button>
                    <button 
                      onClick={() => handleCalcKeyPress(')')}
                      type="button"
                      className="bg-surface-container-high text-on-surface hover:bg-surface-container-highest font-bold h-11 rounded-xl text-center flex items-center justify-center text-sm transition-all cursor-pointer"
                    >
                      )
                    </button>
                    <button 
                      onClick={() => handleCalcKeyPress('/')}
                      type="button"
                      className="bg-primary/10 text-primary hover:bg-primary/20 font-black h-11 rounded-xl text-center flex items-center justify-center text-base transition-all cursor-pointer"
                    >
                      ÷
                    </button>

                    <button 
                      onClick={() => handleCalcKeyPress('7')}
                      type="button"
                      className="bg-surface-container-high text-on-surface hover:bg-surface-container-highest font-black h-11 rounded-xl text-center flex items-center justify-center text-sm transition-all cursor-pointer"
                    >
                      7
                    </button>
                    <button 
                      onClick={() => handleCalcKeyPress('8')}
                      type="button"
                      className="bg-surface-container-high text-on-surface hover:bg-surface-container-highest font-black h-11 rounded-xl text-center flex items-center justify-center text-sm transition-all cursor-pointer"
                    >
                      8
                    </button>
                    <button 
                      onClick={() => handleCalcKeyPress('9')}
                      type="button"
                      className="bg-surface-container-high text-on-surface hover:bg-surface-container-highest font-black h-11 rounded-xl text-center flex items-center justify-center text-sm transition-all cursor-pointer"
                    >
                      9
                    </button>
                    <button 
                      onClick={() => handleCalcKeyPress('*')}
                      type="button"
                      className="bg-primary/10 text-primary hover:bg-primary/20 font-black h-11 rounded-xl text-center flex items-center justify-center text-base transition-all cursor-pointer"
                    >
                      ×
                    </button>

                    <button 
                      onClick={() => handleCalcKeyPress('4')}
                      type="button"
                      className="bg-surface-container-high text-on-surface hover:bg-surface-container-highest font-black h-11 rounded-xl text-center flex items-center justify-center text-sm transition-all cursor-pointer"
                    >
                      4
                    </button>
                    <button 
                      onClick={() => handleCalcKeyPress('5')}
                      type="button"
                      className="bg-surface-container-high text-on-surface hover:bg-surface-container-highest font-black h-11 rounded-xl text-center flex items-center justify-center text-sm transition-all cursor-pointer"
                    >
                      5
                    </button>
                    <button 
                      onClick={() => handleCalcKeyPress('6')}
                      type="button"
                      className="bg-surface-container-high text-on-surface hover:bg-surface-container-highest font-black h-11 rounded-xl text-center flex items-center justify-center text-sm transition-all cursor-pointer"
                    >
                      6
                    </button>
                    <button 
                      onClick={() => handleCalcKeyPress('-')}
                      type="button"
                      className="bg-primary/10 text-primary hover:bg-primary/20 font-black h-11 rounded-xl text-center flex items-center justify-center text-base transition-all cursor-pointer"
                    >
                      -
                    </button>

                    <button 
                      onClick={() => handleCalcKeyPress('1')}
                      type="button"
                      className="bg-surface-container-high text-on-surface hover:bg-surface-container-highest font-black h-11 rounded-xl text-center flex items-center justify-center text-sm transition-all cursor-pointer"
                    >
                      1
                    </button>
                    <button 
                      onClick={() => handleCalcKeyPress('2')}
                      type="button"
                      className="bg-surface-container-high text-on-surface hover:bg-surface-container-highest font-black h-11 rounded-xl text-center flex items-center justify-center text-sm transition-all cursor-pointer"
                    >
                      2
                    </button>
                    <button 
                      onClick={() => handleCalcKeyPress('3')}
                      type="button"
                      className="bg-surface-container-high text-on-surface hover:bg-surface-container-highest font-black h-11 rounded-xl text-center flex items-center justify-center text-sm transition-all cursor-pointer"
                    >
                      3
                    </button>
                    <button 
                      onClick={() => handleCalcKeyPress('+')}
                      type="button"
                      className="bg-primary/10 text-primary hover:bg-primary/20 font-black h-11 rounded-xl text-center flex items-center justify-center text-base transition-all cursor-pointer"
                    >
                      +
                    </button>

                    <button 
                      onClick={() => handleCalcKeyPress('0')}
                      type="button"
                      className="bg-surface-container-high text-on-surface hover:bg-surface-container-highest font-black h-11 rounded-xl text-center flex items-center justify-center text-sm transition-all cursor-pointer"
                    >
                      0
                    </button>
                    <button 
                      onClick={() => handleCalcKeyPress('.')}
                      type="button"
                      className="bg-surface-container-high text-on-surface hover:bg-surface-container-highest font-black h-11 rounded-xl text-center flex items-center justify-center text-sm transition-all cursor-pointer"
                    >
                      .
                    </button>
                    <button 
                      onClick={handleCalcBackspace}
                      type="button"
                      className="bg-surface-container-high text-on-surface-variant hover:bg-surface-container-highest font-bold h-11 rounded-xl text-center flex items-center justify-center text-sm transition-all cursor-pointer"
                    >
                      ⌫
                    </button>
                    <button 
                      onClick={handleCalcEvaluate}
                      type="button"
                      className="bg-primary text-white hover:opacity-90 font-black h-11 rounded-xl text-center flex items-center justify-center text-base transition-all cursor-pointer shadow-md shadow-primary/10"
                    >
                      =
                    </button>
                  </div>

                  {/* Ações */}
                  <div className="flex gap-2">
                    <button
                      onClick={handleCalcCopy}
                      type="button"
                      disabled={!calcExpression && !calcResult}
                      className={cn(
                        "w-full py-2.5 rounded-2xl text-[11px] font-black uppercase tracking-widest transition-all block text-center border cursor-pointer",
                        copiedIndicator 
                          ? "bg-emerald-500 text-white border-emerald-500 shadow-md shadow-emerald-500/10" 
                          : "bg-surface-container-high hover:bg-surface-container-highest text-on-surface-variant border-transparent"
                      )}
                    >
                      {copiedIndicator ? '✓ Copiado!' : 'Copiar Resultado'}
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}
      </AnimatePresence>

      {/* Assign Users Modal */}
      <AnimatePresence>
        {isAssignModalOpen && assigningOrder && (
          <div className="fixed inset-0 z-[100] bg-black/40 backdrop-blur-sm flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-surface-container-lowest w-full max-w-md rounded-[40px] shadow-2xl overflow-hidden"
            >
              <div className="p-8 border-b border-outline-variant/10 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-primary/10 rounded-2xl flex items-center justify-center text-primary">
                    <Users className="w-5 h-5" />
                  </div>
                  <h3 className="text-xl font-headline font-black text-on-surface">Atribuir Equipe</h3>
                </div>
                <button onClick={() => setIsAssignModalOpen(false)}>
                   <X className="w-6 h-6" />
                </button>
              </div>

              <div className="p-8 space-y-2 max-h-[400px] overflow-y-auto">
                {profiles
                  .sort((a, b) => a.name.localeCompare(b.name))
                  .map(profile => {
                  const isAssigned = assigningOrder.assigned_users?.includes(profile.id);
                  return (
                    <button
                      key={profile.id}
                      onClick={() => {
                        const current = assigningOrder.assigned_users || [];
                        const next = isAssigned 
                          ? current.filter(id => id !== profile.id)
                          : [...current, profile.id];
                        setAssigningOrder({ ...assigningOrder, assigned_users: next });
                      }}
                      className={cn(
                        "w-full flex items-center justify-between p-4 rounded-2xl border transition-all",
                        isAssigned 
                          ? "bg-primary/5 border-primary/20 ring-1 ring-primary/20" 
                          : "bg-surface-container-low border-transparent hover:border-outline-variant"
                      )}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-[10px] font-bold text-primary">
                          {profile.name[0]}
                        </div>
                        <div className="text-left">
                          <p className="text-sm font-bold text-on-surface">{profile.name}</p>
                          <p className="text-[10px] text-on-surface-variant">{profile.email}</p>
                        </div>
                      </div>
                      {isAssigned && <CheckCircle2 className="w-5 h-5 text-primary" />}
                    </button>
                  );
                })}
              </div>

              <div className="p-8 pt-0">
                <button 
                  onClick={() => assignUsers(assigningOrder.assigned_users || [])}
                  disabled={isProcessing}
                  className="w-full bg-primary text-white font-bold py-4 rounded-2xl shadow-xl shadow-primary/20 flex items-center justify-center gap-2"
                >
                  {isProcessing ? <Loader2 className="w-5 h-5 animate-spin" /> : <CheckCircle2 className="w-5 h-5" />}
                  Confirmar Equipe
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
